package com.apps.kunalfarmah.realtimetictactoe.model;

public class ImagesBox {

    public ImagesBox(){

    }

    public int imgvw,value;

   public ImagesBox(int no, int val){
        this.imgvw=no;
        this.value =val;
    }
}
